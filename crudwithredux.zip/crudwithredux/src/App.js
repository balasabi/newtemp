import React, { Component } from 'react';
import './App.css';
import UserTable from './view/UserTable'
import AddUserForm from './view/AddUserForm'
import EditUserForm from './view/EditUserForm'
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import CssBaseline from '@material-ui/core/CssBaseline';
import useScrollTrigger from '@material-ui/core/useScrollTrigger';
import Box from '@material-ui/core/Box';
import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import { makeStyles } from '@material-ui/core/styles';
import logoImage from '../src/assets/Images/logo.png';



function ElevationScroll(props) {
  const { children, window } = props;
  // Note that you normally won't need to set the window ref as useScrollTrigger
  // will default to window.
  // This is only being set here because the demo is in an iframe.
  const trigger = useScrollTrigger({
    disableHysteresis: true,
    threshold: 0,
    target: window ? window() : undefined,
  });

  return React.cloneElement(children, {
    elevation: trigger ? 4 : 0,
  });
}

ElevationScroll.propTypes = {
  children: PropTypes.element.isRequired,
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window: PropTypes.func,
};

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
}));


class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      title: '',
      available: false,
      userId: null,
      userAction: "A"
    }

    console.log("*************constructor****************************")
  }

  static getDerivedStateFromProps(props, state) {
    console.log("*************getDerivedStateFromProps****************************")
    return { favoritecolor: props.favcol };
  }

  componentDidMount() {
    console.log("*************componentDidMount****************************")
  }

  shouldComponentUpdate() {
    return true;
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log("*************getSnapshotBeforeUpdate****************************" + prevState)
  }
  componentDidUpdate() {
    console.log("*************componentDidMount****************************")
  }

  // shouldComponentUpdate() {
  //   return false;
  // }

  render() {
    console.log("*************render****************************")

    return (
      <div className="containerScreen">
        <AppBar style={{ background: "#232D47", height: 20 }}>
          <Grid container spacing={2}>
            <Grid item xs>

            </Grid>
            <Grid item xs>
              <Typography style={{ textAlign: "center", fontSize: 10, }}>Expect delivery within 24 hours from order</Typography>
            </Grid>
            <Grid item xs>
              <Typography style={{ textAlign: "left", fontSize: 10, }}>DOWNLOAD FRESHFINS APP</Typography>
            </Grid>
          </Grid>






        </AppBar>
        <div className="container">
          <ElevationScroll >
            <div className="container">
              <AppBar style={{ background: "#2A3758", marginTop: 20 }}>
                <Toolbar>
                  <Grid container spacing={2}>
                    <Grid item xs>

                    </Grid>
                    <Grid item xs>
                      <img alt="icon" src={logoImage} />
                    </Grid>
                    <Grid item xs>
                      <Typography style={{ textAlign: "center", color: "white", marginTop: 25, fontSize: 15, fontWeight: "bold" }} >SEAFOOD</Typography>
                    </Grid>
                    <Grid item xs>
                      <Typography style={{ textAlign: "center", color: "white", marginTop: 25, fontSize: 15, fontWeight: "bold" }} >POULTRY</Typography>
                    </Grid>
                    <Grid item xs>
                      <Typography style={{ textAlign: "center", color: "white", marginTop: 25, fontSize: 15, fontWeight: "bold" }} >WHY FRESHFINS</Typography>
                    </Grid>
                    <Grid item xs>
                    </Grid>
                    <Grid item xs>
                    </Grid>
                    <Grid item xs>
                    </Grid>
                  </Grid>
                </Toolbar>
              </AppBar>
            </div>
          </ElevationScroll>
          <div style={{ marginTop: 100 }} />
          <h1>CRUD With Redux </h1>
          <div className="flex-row">
            {this.state.userAction === "A" ?
              <div className="flex-large">
                <h2>Add user</h2>
                <AddUserForm />
              </div> :
              <div className="flex-large">
                <h2>Add user</h2>
                <EditUserForm userId={this.state.userId} appScreen={this} />
              </div>}
            <div className="flex-large">
              <h2>View users</h2>
              <UserTable appScreen={this} />
            </div>
          </div>
        </div>
        <div style={{ height: 400, background: "#2A3758" }}>
          <div className="container">
            <div style={{ height: 100 }} />
            <Grid container spacing={5}>
              <Grid item xs>
                <img alt="icon" src={logoImage} />
              </Grid>
              <Grid item xs>
                <Typography style={{ textAlign: "center", color: "white", marginTop: 30, fontSize: 10, }}>Expect delivery within 24 hours from order</Typography>
              </Grid>
              <Grid item xs>
                <Typography style={{ textAlign: "center", color: "white", marginTop: 30, fontSize: 10, }} >info@freshfins.com</Typography>
              </Grid>
            </Grid>
          </div>
          <div className="container" style={{ height: 10 }} />
          <div className="container" style={{ height: 1, background: "white" }} />
          <div className="container">
            <div style={{ height: 100 }} />
            <Grid container spacing={5}>
              <Grid item xs>
                <img alt="icon" src={logoImage} />
              </Grid>
              <Grid item xs>
                <Typography style={{ textAlign: "center", color: "white", marginTop: 30, fontSize: 10, }}>Expect delivery within 24 hours from order</Typography>
              </Grid>
              <Grid item xs>
                <Typography style={{ textAlign: "center", color: "white", marginTop: 30, fontSize: 10, }} >info@freshfins.com</Typography>
              </Grid>
            </Grid>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
