import { combineReducers } from 'redux';
import  UserReducer from '../reducers/UserReducer';
const allReducers = combineReducers({
     UserReducer
});

export default allReducers;
